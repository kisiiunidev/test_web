from dictcli.client import DictionaryClient

def test_client_url():
    client = DictionaryClient("https://example.com/api/")
    assert client.api_url == "https://example.com/api"
