from __future__ import annotations
import json
from .client import WordEntry

def format_entry(entry: WordEntry, show_examples: bool = False) -> str:
    lines = ["", entry.word, "=" * len(entry.word)]
    phonetics = [p.text for p in entry.phonetics if p.text]
    if phonetics:
        lines += [f"Pronunciation: {', '.join(phonetics)}"]
    lines.append("")

    for meaning in entry.meanings:
        lines += [meaning.part_of_speech, "-" * len(meaning.part_of_speech)]
        for i, definition in enumerate(meaning.definitions, 1):
            lines.append(f"{i}. {definition.text}")
            if show_examples and definition.example:
                lines.append(f"   Example: {definition.example}")
            if definition.synonyms:
                lines.append("   Synonyms: " + ", ".join(definition.synonyms))
            if definition.antonyms:
                lines.append("   Antonyms: " + ", ".join(definition.antonyms))
        lines.append("")

    if entry.source_urls:
        lines.append("Sources:")
        lines.extend(f"  {url}" for url in entry.source_urls)
    return "\n".join(lines)

def format_json(entry: WordEntry) -> str:
    return json.dumps(entry.to_dict(), ensure_ascii=False, indent=2)
