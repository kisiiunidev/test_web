from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any
import requests

DEFAULT_API_URL = "https://api.dictionaryapi.dev/api/v2/entries/en"

class DictionaryError(Exception):
    pass

class WordNotFoundError(DictionaryError):
    pass

@dataclass
class Definition:
    text: str
    example: str | None = None
    synonyms: list[str] = field(default_factory=list)
    antonyms: list[str] = field(default_factory=list)

@dataclass
class Meaning:
    part_of_speech: str
    definitions: list[Definition] = field(default_factory=list)

@dataclass
class Phonetic:
    text: str | None = None
    audio: str | None = None

@dataclass
class WordEntry:
    word: str
    phonetics: list[Phonetic] = field(default_factory=list)
    meanings: list[Meaning] = field(default_factory=list)
    source_urls: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "word": self.word,
            "phonetics": [{"text": p.text, "audio": p.audio} for p in self.phonetics],
            "meanings": [{
                "part_of_speech": m.part_of_speech,
                "definitions": [{
                    "definition": d.text,
                    "example": d.example,
                    "synonyms": d.synonyms,
                    "antonyms": d.antonyms,
                } for d in m.definitions],
            } for m in self.meanings],
            "source_urls": self.source_urls,
        }

class DictionaryClient:
    def __init__(self, api_url: str = DEFAULT_API_URL, timeout: float = 10.0):
        self.api_url = api_url.rstrip("/")
        self.timeout = timeout

    def lookup(self, word: str) -> WordEntry:
        word = word.strip()
        if not word:
            raise DictionaryError("Word cannot be empty.")

        try:
            response = requests.get(
                f"{self.api_url}/{word}",
                timeout=self.timeout,
                headers={"User-Agent": "dictionary-cli/1.0", "Accept": "application/json"},
            )
        except requests.RequestException as exc:
            raise DictionaryError(f"Network error: {exc}") from exc

        if response.status_code == 404:
            raise WordNotFoundError(f"No dictionary entry found for '{word}'.")
        if not response.ok:
            raise DictionaryError(f"Dictionary API returned HTTP {response.status_code}.")

        try:
            data = response.json()
        except ValueError as exc:
            raise DictionaryError("The dictionary API returned invalid JSON.") from exc

        if not isinstance(data, list) or not data:
            raise DictionaryError("Unexpected response from dictionary API.")

        return self._parse_entry(data[0])

    def _parse_entry(self, data: dict[str, Any]) -> WordEntry:
        phonetics = [
            Phonetic(text=p.get("text"), audio=p.get("audio"))
            for p in data.get("phonetics", [])
            if isinstance(p, dict)
        ]

        meanings = []
        for m in data.get("meanings", []):
            if not isinstance(m, dict):
                continue
            definitions = [
                Definition(
                    text=d.get("definition", ""),
                    example=d.get("example"),
                    synonyms=d.get("synonyms", []),
                    antonyms=d.get("antonyms", []),
                )
                for d in m.get("definitions", [])
                if isinstance(d, dict)
            ]
            meanings.append(Meaning(
                part_of_speech=m.get("partOfSpeech", "unknown"),
                definitions=definitions,
            ))

        return WordEntry(
            word=data.get("word", ""),
            phonetics=phonetics,
            meanings=meanings,
            source_urls=data.get("sourceUrls", []),
        )
