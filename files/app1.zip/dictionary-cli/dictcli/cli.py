from __future__ import annotations
import argparse
import sys
from .cache import Cache
from .client import DictionaryClient, DictionaryError, WordNotFoundError, WordEntry, Phonetic, Meaning, Definition
from .formatter import format_entry, format_json

def entry_from_dict(data: dict) -> WordEntry:
    return WordEntry(
        word=data["word"],
        phonetics=[Phonetic(**p) for p in data.get("phonetics", [])],
        meanings=[
            Meaning(
                part_of_speech=m["part_of_speech"],
                definitions=[
                    Definition(
                        text=d["definition"],
                        example=d.get("example"),
                        synonyms=d.get("synonyms", []),
                        antonyms=d.get("antonyms", []),
                    )
                    for d in m.get("definitions", [])
                ],
            )
            for m in data.get("meanings", [])
        ],
        source_urls=data.get("source_urls", []),
    )

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="dictcli", description="Look up English words from the command line.")
    parser.add_argument("word", nargs="?", help="Word to look up.")
    parser.add_argument("--json", action="store_true", help="Output JSON.")
    parser.add_argument("--examples", action="store_true", help="Show usage examples.")
    parser.add_argument("--no-cache", action="store_true", help="Do not use the local cache.")
    parser.add_argument("--clear-cache", action="store_true", help="Clear cached dictionary entries.")
    parser.add_argument("--api-url", default=None, help="Dictionary API base URL.")
    return parser

def main() -> None:
    args = build_parser().parse_args()
    cache = Cache()

    if args.clear_cache:
        cache.clear()
        print("Dictionary cache cleared.")
        return

    if not args.word:
        build_parser().print_help()
        sys.exit(1)

    entry = None
    if not args.no_cache:
        cached = cache.get(args.word.lower())
        if cached:
            entry = entry_from_dict(cached)

    try:
        if entry is None:
            client = DictionaryClient(api_url=args.api_url or "https://api.dictionaryapi.dev/api/v2/entries/en")
            entry = client.lookup(args.word)
            if not args.no_cache:
                cache.set(args.word.lower(), entry.to_dict())
    except WordNotFoundError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(2)
    except DictionaryError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(3)

    print(format_json(entry) if args.json else format_entry(entry, args.examples))

if __name__ == "__main__":
    main()
