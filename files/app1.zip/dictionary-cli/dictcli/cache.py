from __future__ import annotations
import hashlib
import json
from pathlib import Path
from typing import Any

class Cache:
    def __init__(self, directory: str | None = None):
        self.directory = Path(directory).expanduser() if directory else Path.home() / ".cache" / "dictionary-cli"
        self.directory.mkdir(parents=True, exist_ok=True)

    def _filename(self, key: str) -> Path:
        digest = hashlib.sha256(key.encode("utf-8")).hexdigest()
        return self.directory / f"{digest}.json"

    def get(self, key: str) -> dict[str, Any] | None:
        path = self._filename(key)
        if not path.exists():
            return None
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return None

    def set(self, key: str, value: dict[str, Any]) -> None:
        self._filename(key).write_text(
            json.dumps(value, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    def clear(self) -> None:
        for path in self.directory.glob("*.json"):
            try:
                path.unlink()
            except OSError:
                pass
