# Dictionary CLI

A Python command-line dictionary client using a public dictionary API.

## Install

```bash
python -m venv .venv
```

Linux/macOS:
```bash
source .venv/bin/activate
```

Windows PowerShell:
```powershell
.venv\Scripts\Activate.ps1
```

Then:
```bash
pip install -e .
```

## Usage

```bash
dictcli hello
dictcli hello --examples
dictcli hello --json
dictcli hello --no-cache
dictcli --clear-cache
dictcli --help
```

You can also run:
```bash
python -m dictcli hello
```

## Cache

Cached results are stored in `~/.cache/dictionary-cli/`.

## Note

This implementation does not scrape Dictionary.com. If you obtain authorized Dictionary.com API access, the client can be adapted to its documented API.
